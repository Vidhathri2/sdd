<!-- SPECKIT START -->
For additional context about technologies to be used, project structure,
shell commands, and other important information, read the current plan
specs/001-cpq-quote-builder/plan.md
<!-- SPECKIT END -->
